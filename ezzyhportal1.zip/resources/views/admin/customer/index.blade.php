@extends('layouts.admin_app')
@section('content')

<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row">
      <div class="col-lg-12">
        <div class="white_card card_height_100 mb_30 pt-4">
          <div class="white_card_body">
            <div class="QA_section">
              <div class="white_box_tittle list_header">
                <h4> Customer List</h4>
                <!-- <div class="box_right d-flex lms_block">
                  <a class="btn btn-primary" href="{{ route('dealer.create') }}"> Create New Customer</a>
                </div> -->
              </div>

              <div class="row mb-4">
                <div class="col-md-5"></div>
              <div class="col-md-7">
                  <h4 class="text-center">Generates affiliate link to Customer</h4>
                </div>
                <div class="col-md-6">
                <div class="row">
                  <div class="col-md-6">
                    <form action=""  class="mt-3" >
                      <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Search" name="search">
                        <div class="input-group-append">
                          <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="col-md-5">
                    <form id="sortForm" class="mt-3">
                      <select name="loan_status" id="sort" class="form-control">
                        <option value="">Sort By Status</option>
                        <option value="0">Pending</option>
                        <option value="1">Approved</option>
                        <option value="2">Rejected</option>
                      </select>
                    </form>
                  </div>
                </div>
                </div>
                <div class="col-md-6 text-center">
                  <div class="input-group mt-3">
                  <input type="text" class="form-control" value="https://ezzyhportal.com/userform/{{Auth::user()->id}}" id="myInput" style="padding: 7px; font-weight: 800; border: 1px solid #884ffb; color: #884ffb; border-radius: 5px; background: transparent;" readonly="true">
                  <div class="input-group-append">
                  <button type="button" class="btn btn-primary" onclick="myFunctionCopy()">Copy Affliate</button>
                  </div>
                  </div>
                </div>
                {{-- <div class="col-md-2 text-center">
                  <a href="#" class="btn btn-primary" onclick="myFunctionCopy()">Copy Affliate</a>
                </div> --}}
              </div> 

              @if ($message = Session::get('success'))
              <div class="alert alert-success">
                <p>{{ $message }}</p>
              </div>
              @endif

              <div class="QA_table mb_30">
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Register Id</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Email</th>
                        <th>Refer By Id</th>
                        <th>Refer By Name</th>
                        <th>Occupation Type</th>
                        <th>Company Name</th>
                        <th>Loan Status</th>
                        <th style="min-width:200px;">Import/Export</th>
                        <th >Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      @if (!empty($data))
                      @foreach ($data as $user)
                      @php
                          $name = App\Models\User::where('id',$user->sid)->pluck('name');
                      @endphp
                      <tr>
                        <td>{{ ++$i }}</td>
                        <td>{{$user->register_id}}</td>
                        <td>{{$user->fullname}}</td>
                        <td>{{$user->gender}}</td>
                        <td>{{$user->email}}</td>
                        <td>{{$user->sid}}</td>
                        <td>{{$name[0]}}</td>
                        <td>{{$user->occupation_type}}</td>
                        <td>{{$user->company_name}}</td>
                        <td>
                          @if ($user->loan_status == 0)
                            <span class="text-warning">Pending</span>
                          @elseif($user->loan_status == 1)
                            <span class="text-success">Approved</span>
                          @else
                            <span class="text-danger">Rejected</span>
                          @endif
                        </td>
                        </td>
                        <td>
                          <a href="{{route('export')}}" class="btn-info btn">Export</a>
                          <a href="#" class="btn-primary btn">Import</a>
                        </td>
                        <td class="d-flex">
                          {{-- <a class="btn btn-info" href="">Show</a> --}}
                          <a class="btn btn-primary" href="">Edit</a>
                          <a href="{{route('admin.deleteCustomer',['id'=>$user->id])}}" class="btn btn-danger">Delete</a>
                          <form action="{{route('admin.updateLoanStatus')}}" method="post" class="d-flex">
                            @csrf
                            <input type="hidden" name="id" value="{{$user->id}}">
                            @if ($user->loan_status == 0)
                            <button type="submit" class="btn btn-warning ml-2" name="loan_status" value="1">Approve</button>
                            <button type="submit" class="btn btn-danger" name="loan_status" value="0">Reject</button>
                            @elseif($user->loan_status == 1)
                                <button type="submit" class="btn btn-danger" name="loan_status" value="0">Reject</button>
                            @endif
                            </form>
                        </td>
                      </tr>
                      @endforeach
                      @else
                        <div>No Data found</div>
                      @endif

                    </tbody>
                  </table>
                </div>

                {!! $data->render() !!}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
<script>
  $('#sort').change(function(){
    $('#sortForm').submit();
    // var search = $(this).val();
    // $.ajax({
    //   url:"",
    //   data:{
    //     search:search
    //   },
    //   success:function(res){
    //     console.log(res);
    //     location.reload();
    //   }
    // })
  });
</script>
@endsection