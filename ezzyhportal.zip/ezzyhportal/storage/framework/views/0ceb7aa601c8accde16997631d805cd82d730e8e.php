
<?php $__env->startSection('content'); ?>

<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row">
      <div class="col-lg-12">
        <div class="white_card card_height_100 mb_30 pt-4">
          <div class="white_card_body">
            <div class="QA_section">
              <div class="white_box_tittle list_header">
                <h4>Subadmin Users List</h4>
                <div class="box_right d-flex lms_block">
                  <a class="btn btn-primary" href="<?php echo e(route('subadmin.create')); ?>"> Create New User</a>
                </div>
              </div>

              <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
              </div>
              <?php endif; ?>

              <div class="QA_table mb_30">
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Roles</th>
                        <th width="280px">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                          <?php if(!empty($user->getRoleNames())): ?>
                          <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <label class="badge badge-success"><?php echo e($v); ?></label>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </td>
                        <td>
                          <a class="btn btn-info" href="<?php echo e(route('subadmin.show',$user->id)); ?>">Show</a>
                          <a class="btn btn-primary" href="<?php echo e(route('subadmin.edit',$user->id)); ?>">Edit</a>
                          <?php echo Form::open(['method' => 'DELETE','route' => ['subadmin.destroy', $user->id],'style'=>'display:inline']); ?>

                          <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                          <?php echo Form::close(); ?>

                          
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>

                <?php echo $data->render(); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ezzyhportal\resources\views/admin/subadmin/index.blade.php ENDPATH**/ ?>