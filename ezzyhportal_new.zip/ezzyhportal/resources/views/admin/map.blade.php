@extends('layouts.admin_app')
@section('content')

 <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card card-plain">
              <div class="card-header">
                Google Maps
              </div>
              <div class="card-body">
                <div id="map" class="map"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      @endsection