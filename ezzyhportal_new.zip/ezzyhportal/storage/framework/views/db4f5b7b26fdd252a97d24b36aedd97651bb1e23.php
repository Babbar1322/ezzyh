
<?php $__env->startSection('content'); ?>

<div class="main_content_iner overly_inner ">
  <div class="container-fluid p-0 ">
    <div class="row">
      <div class="col-lg-12">
        <div class="white_card card_height_100 mb_30 pt-4">
          <div class="white_card_body">
            <div class="QA_section">
              <div class="white_box_tittle list_header">
                <h4>Dealer Users List</h4>
                <div class="box_right d-flex lms_block">
                  <!-- <a class="btn btn-primary" href="<?php echo e(route('subdealer.create')); ?>"> Create New Sub Dealer</a> -->
                </div>
              </div>

              <div class="row mb-4">
                <div class="col-md-12">
                  <h4 class="text-center">Generates affiliate link to Subdealer</h4>
                </div>
                <div class="col-md-4"></div>
                <div class="col-md-6 text-center">
                  <input type="text" value="https://webcyst.com/ezzyhportal/subdealerRegister/<?php echo e(Auth::user()->id); ?>" id="myInput" style="width: 100%;padding: 7px; font-weight: 800; border: 1px solid #884ffb; color: #884ffb; border-radius: 5px; background: transparent;" readonly="true">
                </div>
                <div class="col-md-2 text-center">
                  <a href="#" class="btn btn-primary" onclick="myFunctionCopy()">Copy</a>
                </div>
              </div>

              <!-- <div class="row mb-4">
                <div class="col-md-4"></div>
                <div class="col-md-6 text-center">
                  <input type="text" value="https://webcyst.com/ezzyhportal/userform/<?php echo e(Auth::user()->id); ?>" id="myInput" style="width: 100%;padding: 7px; font-weight: 800; border: 1px solid #884ffb; color: #884ffb; border-radius: 5px; background: transparent;" readonly="true">
                </div>
                <div class="col-md-2 text-center">
                  <a href="#" class="btn btn-primary" onclick="myFunctionCopy()">Copy Affliate</a>
                </div>
              </div> -->

              <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
              </div>
              <?php endif; ?>

              <div class="QA_table mb_30">
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Log Code</th>
                        <th>Password</th>
                        <th>Email</th>
                        <th>Roles</th>
                        <th width="280px">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($user->id != Auth::user()->id): ?>
                      <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->login_code); ?></td>
                        <td><?php echo e($user->showPass); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                          <?php if(!empty($user->getRoleNames())): ?>
                          <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <label class="badge badge-success"><?php echo e($v); ?></label>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </td>
                        <td style="width: 44%;">
                          <a class="btn btn-info" href="<?php echo e(route('subdealer.show',$user->id)); ?>">Show</a>
                          <a class="btn btn-primary" href="<?php echo e(route('subdealer.edit',$user->id)); ?>">Edit</a>
                          <?php echo Form::open(['method' => 'DELETE','route' => ['subdealer.destroy', $user->id],'style'=>'display:inline']); ?>

                          <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                          <?php echo Form::close(); ?>

                          <a class="btn btn-warning" href="<?php echo e(route('customer.index',$user->id)); ?>">Customer</a>
                          <button type="button" data-id="<?php echo e($user->id); ?>" class="btn btn-secondary mybtn " >
                            Code
                          </button>
                        </td>
                      </tr>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>

                <?php echo $data->render(); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ezzyhportal\resources\views/admin/subdealer/index.blade.php ENDPATH**/ ?>