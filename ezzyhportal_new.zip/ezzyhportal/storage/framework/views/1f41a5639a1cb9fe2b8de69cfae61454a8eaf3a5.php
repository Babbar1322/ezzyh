<!DOCTYPE html>
<html>
<head>
    <title>Ezzyhportal</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH E:\ezzyhportal\resources\views/admin/mailUser.blade.php ENDPATH**/ ?>